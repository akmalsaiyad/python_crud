Python CRUD operation using SQLite

Run using command in cmd : python app.py